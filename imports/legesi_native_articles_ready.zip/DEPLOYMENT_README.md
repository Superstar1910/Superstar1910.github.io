# Legesi.xyz — native article migration package

Contains 38 author-export-derived Substack articles in native HTML.

## Publication

1. Checkout `Superstar1910/Superstar1910.github.io` locally.
2. Unzip this package into the repository root (do not overwrite existing pages without reviewing the diff).
3. Reconcile `migration-records.json` into `static/data/articles.json` by `originalUrl` rather than only slug. For matching existing records, preserve validated research linkages, original dates and review notes; replace date values only when confirmed by source export.
4. Inspect all images and third-party embeds; some image URLs may depend on external hosts.
5. Run `python scripts/validate_articles.py` and `python scripts/build_article_feeds.py`.
6. Review HTML output and disclosures, then commit and deploy through GitHub Pages.

**Do not upload the export ZIP itself to the public repo.** This package includes only article HTML and publication metadata, not subscriber analytics.

The generated article pages represent the original archived editions. Subsequent research changes should be separately dated and linked to a versioned repository commit.
